/* ══════════════════════════════════════════════════════════════
   WORLDLIGHT TOUR — MAIN JS
   Cursor · Nav · Scroll Reveal · Counters · Particles
══════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ─── CURSOR ─────────────────────────────────────────────── */
  const dot = document.querySelector('.cursor-dot');
  const circle = document.querySelector('.cursor-circle');
  let cx = 0, cy = 0, tx = 0, ty = 0;

  if (dot && circle) {
    document.addEventListener('mousemove', e => {
      tx = e.clientX; ty = e.clientY;
      dot.style.left = tx + 'px'; dot.style.top = ty + 'px';
    });
    const animCursor = () => {
      cx += (tx - cx) * .11; cy += (ty - cy) * .11;
      circle.style.left = cx + 'px'; circle.style.top = cy + 'px';
      requestAnimationFrame(animCursor);
    };
    animCursor();
    document.addEventListener('mouseleave', () => {
      dot.style.opacity = '0'; circle.style.opacity = '0';
    });
    document.addEventListener('mouseenter', () => {
      dot.style.opacity = '1'; circle.style.opacity = '1';
    });
  }

  /* ─── NAV COMPACT ON SCROLL ─────────────────────────────── */
  const nav = document.querySelector('.nav');
  if (nav) {
    const onScroll = () => nav.classList.toggle('compact', window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ─── MOBILE NAV ─────────────────────────────────────────── */
  const hamburger = document.querySelector('.hamburger');
  const overlay = document.querySelector('.nav-overlay');
  let menuOpen = false;

  if (hamburger && overlay) {
    hamburger.addEventListener('click', () => {
      menuOpen = !menuOpen;
      overlay.classList.toggle('open', menuOpen);
      const spans = hamburger.querySelectorAll('span');
      if (menuOpen) {
        spans[0].style.transform = 'rotate(45deg) translate(4px,4px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(4px,-4px)';
      } else {
        spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
      }
    });
    overlay.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      menuOpen = false; overlay.classList.remove('open');
      hamburger.querySelectorAll('span').forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
    }));
  }

  /* ─── COOKIE BANNER ──────────────────────────────────────── */
  const cookieBar = document.querySelector('.cookie-bar');
  if (cookieBar && !localStorage.getItem('wl_cookie')) {
    setTimeout(() => cookieBar.classList.add('show'), 1500);
    const dismiss = () => {
      cookieBar.style.transform = 'translateY(100%)';
      localStorage.setItem('wl_cookie', '1');
    };
    cookieBar.querySelector('.cookie-accept')?.addEventListener('click', dismiss);
    cookieBar.querySelector('.cookie-decline')?.addEventListener('click', dismiss);
  } else if (cookieBar) {
    cookieBar.remove();
  }

  /* ─── SCROLL REVEAL ──────────────────────────────────────── */
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('up'); }
    });
  }, { threshold: .1, rootMargin: '0px 0px -60px 0px' });

  document.querySelectorAll('.reveal, .reveal-l, .reveal-r, .reveal-scale')
    .forEach(el => revealObserver.observe(el));

  /* ─── COUNTER ANIMATION ──────────────────────────────────── */
  window.animateCount = function(el, target, fmt) {
    if (el.dataset.counted) return;
    el.dataset.counted = '1';
    const start = performance.now();
    const dur = 2400;
    const update = now => {
      const p = Math.min((now - start) / dur, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      const val = Math.floor(ease * target);
      el.textContent = fmt ? fmt(val) : val.toLocaleString();
      if (p < 1) requestAnimationFrame(update);
      else el.textContent = fmt ? fmt(target) : target.toLocaleString();
    };
    requestAnimationFrame(update);
  };

  const counterObserver = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseInt(el.dataset.count || 0);
      const suffix = el.dataset.suffix || '';
      const prefix = el.dataset.prefix || '';
      animateCount(el, target, v => {
        const disp = v >= 1e6 ? (v/1e6).toFixed(1)+'M' : v >= 1e3 ? (v/1e3).toFixed(0)+'K' : v.toLocaleString();
        return prefix + disp + suffix;
      });
    });
  }, { threshold: .4 });

  document.querySelectorAll('[data-count]').forEach(el => counterObserver.observe(el));

  /* ─── COUNTDOWN ──────────────────────────────────────────── */
  const finale = new Date('2025-12-31T20:00:00');
  const cdEls = {
    d: document.getElementById('cd-d'),
    h: document.getElementById('cd-h'),
    m: document.getElementById('cd-m'),
    s: document.getElementById('cd-s'),
  };
  if (cdEls.d) {
    const tick = () => {
      const diff = Math.max(0, finale - new Date());
      cdEls.d.textContent = String(Math.floor(diff/86400000)).padStart(3,'0');
      cdEls.h.textContent = String(Math.floor((diff%86400000)/3600000)).padStart(2,'0');
      cdEls.m.textContent = String(Math.floor((diff%3600000)/60000)).padStart(2,'0');
      cdEls.s.textContent = String(Math.floor((diff%60000)/1000)).padStart(2,'0');
    };
    tick(); setInterval(tick, 1000);
  }

  /* ─── LIVE DONATION COUNTER ──────────────────────────────── */
  const dc = document.getElementById('live-donation');
  if (dc) {
    let base = 2_847_391;
    const fmt = n => '$' + n.toLocaleString('en-US');
    dc.textContent = fmt(base);
    setInterval(() => {
      base += Math.floor(Math.random() * 180 + 20);
      dc.textContent = fmt(base);
    }, 2800);
  }

  /* ─── DONATE AMOUNT SELECTION ────────────────────────────── */
  const amountBtns = document.querySelectorAll('.amount-btn');
  amountBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      amountBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const customInput = document.getElementById('custom-amount');
      if (customInput) customInput.value = '';
    });
  });

  const donateBtn = document.getElementById('donate-submit');
  if (donateBtn) {
    donateBtn.addEventListener('click', () => {
      const active = document.querySelector('.amount-btn.active');
      const custom = document.getElementById('custom-amount')?.value;
      const amount = custom || active?.dataset.amount || '100';
      showToast(`Thank you! Redirecting to secure checkout for $${amount}...`, 'success');
    });
  }

  /* ─── NEWSLETTER ─────────────────────────────────────────── */
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = newsletterForm.querySelector('input[type=email]').value;
      if (!email) return;
      showToast('Welcome to the WorldLight Movement! ✦ Check your inbox.', 'success');
      newsletterForm.reset();
    });
  }

  /* ─── TOAST NOTIFICATIONS ────────────────────────────────── */
  window.showToast = function(msg, type = 'info') {
    const t = document.createElement('div');
    t.className = `toast toast-${type}`;
    t.textContent = msg;
    t.style.cssText = `
      position:fixed; bottom:2rem; right:2rem; z-index:9999;
      background:${type==='success'?'rgba(201,168,76,.15)':'rgba(79,195,247,.1)'};
      border:1px solid ${type==='success'?'var(--gold)':'var(--neon-sky)'};
      color:var(--white); padding:1rem 1.5rem; font-family:var(--ui);
      font-size:.85rem; letter-spacing:.05em; max-width:380px;
      backdrop-filter:blur(12px); animation:slideUp .4s ease;
    `;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .4s'; setTimeout(()=>t.remove(),400); }, 4000);
  };

  /* ─── PARALLAX HERO ──────────────────────────────────────── */
  const heroImg = document.querySelector('.hero-parallax-img');
  if (heroImg) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      heroImg.style.transform = `scale(1.08) translateY(${y * .4}px)`;
    }, { passive: true });
  }

  /* ─── MARQUEE PAUSE ON HOVER ─────────────────────────────── */
  document.querySelectorAll('.marquee-track').forEach(track => {
    track.addEventListener('mouseenter', () => track.style.animationPlayState = 'paused');
    track.addEventListener('mouseleave', () => track.style.animationPlayState = 'running');
  });

  /* ─── PROGRESS BAR ───────────────────────────────────────── */
  const progress = document.getElementById('scroll-progress');
  if (progress) {
    window.addEventListener('scroll', () => {
      const pct = window.scrollY / (document.body.scrollHeight - window.innerHeight) * 100;
      progress.style.width = pct + '%';
    }, { passive: true });
  }

  /* ─── VIDEO MODAL ────────────────────────────────────────── */
  const playBtn = document.getElementById('play-trailer');
  const modal = document.getElementById('video-modal');
  const modalClose = document.getElementById('modal-close');
  if (playBtn && modal) {
    playBtn.addEventListener('click', () => {
      modal.style.display = 'flex';
      setTimeout(() => modal.style.opacity = '1', 10);
    });
    modalClose?.addEventListener('click', () => {
      modal.style.opacity = '0';
      setTimeout(() => modal.style.display = 'none', 400);
    });
    modal.addEventListener('click', e => {
      if (e.target === modal) {
        modal.style.opacity = '0';
        setTimeout(() => modal.style.display = 'none', 400);
      }
    });
  }

  /* ─── MAP DOT TOOLTIPS ───────────────────────────────────── */
  document.querySelectorAll('.map-city').forEach(dot => {
    dot.addEventListener('mouseenter', e => {
      const tooltip = document.getElementById('map-tooltip');
      if (!tooltip) return;
      tooltip.textContent = dot.dataset.city;
      tooltip.style.opacity = '1';
    });
    dot.addEventListener('mouseleave', () => {
      const tooltip = document.getElementById('map-tooltip');
      if (tooltip) tooltip.style.opacity = '0';
    });
    dot.addEventListener('mousemove', e => {
      const tooltip = document.getElementById('map-tooltip');
      if (!tooltip) return;
      tooltip.style.left = (e.clientX + 14) + 'px';
      tooltip.style.top = (e.clientY - 30) + 'px';
    });
  });

  console.log('%c⚡ WORLDLIGHT TOUR', 'color:#C9A84C;font-size:2rem;font-weight:700;font-family:serif');
  console.log('%cA Voice of Hope — worldlighttour.org', 'color:rgba(248,244,238,.5);font-size:.8rem');
});
